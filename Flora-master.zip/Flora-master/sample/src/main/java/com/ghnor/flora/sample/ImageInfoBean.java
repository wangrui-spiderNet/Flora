package com.ghnor.flora.sample;

import android.graphics.Bitmap;

/**
 * Created by ghnor on 2017/6/25.
 * ghnor.me@gmail.com
 */

public class ImageInfoBean {
    String path;
    long size;
    int width;
    int height;
    Bitmap img;
}
