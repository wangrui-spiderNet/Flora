package com.ghnor.flora.spec;

/**
 * Created by ghnor on 2017/6/16.
 * email: ghnor.me@gmail.com
 * desc:
 */

public class CompressSource<T> {
    protected T source;
}
