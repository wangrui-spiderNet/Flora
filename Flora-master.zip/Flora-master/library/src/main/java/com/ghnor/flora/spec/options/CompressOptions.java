package com.ghnor.flora.spec.options;

/**
 * Created by ghnor on 2017/8/27.
 * ghnor.me@gmail.com
 */

public abstract class CompressOptions implements Cloneable {
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}