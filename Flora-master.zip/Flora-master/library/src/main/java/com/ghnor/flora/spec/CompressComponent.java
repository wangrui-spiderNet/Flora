package com.ghnor.flora.spec;

/**
 * Created by ghnor on 2017/8/26.
 * ghnor.me@gmail.com
 */

public class CompressComponent<T> extends CompressSource<T> {
    protected CompressSpec compressSpec;
}
