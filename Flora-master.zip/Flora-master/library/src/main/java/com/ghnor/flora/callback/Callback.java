package com.ghnor.flora.callback;

/**
 * Created by ghnor on 2017/7/5.
 * ghnor.me@gmail.com
 */

public interface Callback<T> {

    void callback(T t);

}
